import json

def collection_lambda_handler(event, context):

    return "test_return for collection"