import json

def check_data_handler(event, context):

    return "test_return for check_data"