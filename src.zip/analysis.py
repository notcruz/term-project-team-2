import json

def analysis_handler(event, context):

    return {
        "nameScanned": "Paul Rudd",
        "data": "This is test return data lol"
    }